angular.module('app.controllers', [])
  
.controller('illertimesCtrl', function($scope) {

})
   
.controller('loginCtrl', function($scope) {

})
   
.controller('beginPageCtrl', function($scope) {

})
   
.controller('storyboardAddInsCtrl', function($scope) {

})
   
.controller('helpCtrl', function($scope) {

})
   
.controller('signupCtrl', function($scope) {

})
   
.controller('newStoryOrExistingStoryCtrl', function($scope) {

})
   
.controller('editStoryCtrl', function($scope) {

})
   
.controller('addToYourExistingStoryCtrl', function($scope) {

})
   
.controller('userProfileCtrl', function($scope) {

})
 